MDX Import/Export plugin for 3ds Max v2.0.3
Updated by NiNtoxicated (madyavic@gmail.com) to v2.0.3 on 28th June 2010
- Now works with later versions of 3ds Max
- Fixed a bug that crashed the script due to not refreshing the viewports after adding bones to skin modifier
- Updated animation code, now imports animations correctly
- Updated the vertex normal code so that the correct custom vertex normals are being applied
- Added import as M3 option for importing attachments/animations as M3 objects/structures if correct sc2objects.ms is loaded

Originally created by Philip Laing. All credits for the original source go to him!
Thanks to BlinkBoy from The Hive Workshop for help with animations

Head to http://www.sc2mapster.com/ for more information
